// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2017-2020 Egor Pugin <egor.pugin@gmail.com>

#include "detect.h"

#include "../misc/cmVSSetupHelper.h"
#include "../command.h"
#include "../program_version_storage.h"
#include "../target/target2.h"

#include <boost/algorithm/string.hpp>
#include <primitives/command.h>

#include <regex>
#include <string>

#include <primitives/log.h>
DECLARE_STATIC_LOGGER(logger, "compiler.detect");

// TODO: actually detect.cpp may be rewritten as entry point

namespace sw
{

std::map<path, String> &getMsvcIncludePrefixes()
{
    static std::map<path, String> prefixes;
    return prefixes;
}

static String detectMsvcPrefix(builder::detail::ResolvableCommand c)
{
    // examples:
    // "Note: including file: filename\r" (english)
    // "Some: other lang: filename\r"
    // "Some: other lang  filename\r" (ita)

    auto &p = getMsvcIncludePrefixes();
    if (!p[c.getProgram()].empty())
        return p[c.getProgram()];

    auto basefn = support::get_temp_filename("cliprefix");
    auto fn = path(basefn) += ".c";
    auto hfn = path(basefn) += ".h";
    String contents = "#include \"" + to_string(normalize_path(hfn)) + "\"\r\nint dummy;";
    auto obj = path(fn) += ".obj";
    write_file(fn, contents);
    write_file(hfn, "");
    c.push_back("/showIncludes");
    c.push_back("/c");
    c.push_back(fn);
    c.push_back("/Fo" + to_string(normalize_path_windows(obj)));
    std::error_code ec;
    c.execute(ec);
    fs::remove(obj);
    fs::remove(fn);
    fs::remove(hfn);

    if (!c.exit_code)
        throw SW_RUNTIME_ERROR("Cannot run: " + to_printable_string(c.getProgram()));

    auto error = [&c](const String &reason)
    {
        return "Cannot match VS include prefix (" + reason + "):\n" + c.out.text + "\nstderr:\n" + c.err.text;
    };

    auto get_env = [&c]()
    {
        String s;
        for (auto &[k, v] : c.environment)
            s += k + ": " + v + "\n";
        return s;
    };

    auto lines = split_lines(c.out.text);
    if (lines.empty())
    {
        LOG_TRACE(logger, "Empty stdout from '" + to_printable_string(c.getProgram()) + "', trying stderr. Cmd: " + c.print() + "\nEnv: " + get_env());
        lines = split_lines(c.err.text);
        if (lines.empty())
        {
            LOG_TRACE(logger, "error code = " << *c.exit_code);
            throw SW_RUNTIME_ERROR(error("Bad output: " + c.print() + "\nEnv: " + get_env()));
        }
    }

    String s = R"((.*?\s)[a-zA-Z]:[\\\/].*)" + hfn.stem().string() + "\\" + hfn.extension().string();
    std::regex r(s);
    std::smatch m;
    // clang-cl does not output filename -> lines.size() == 1
    if (!std::regex_search(lines.size() > 1 ? lines[1] : lines[0], m, r))
    {
        LOG_TRACE(logger, "stdout = " << c.out.text);
        LOG_TRACE(logger, "stderr = " << c.err.text);
        LOG_TRACE(logger, "error code = " << *c.exit_code);
        LOG_TRACE(logger, "Cmd: " + c.print() + "\nEnv: " + get_env());
        throw SW_RUNTIME_ERROR(error("regex_search failed"));
    }
    return p[c.getProgram()] = m[1].str();
}

const StringSet &getCppHeaderFileExtensions()
{
    static const StringSet header_file_extensions{
        ".h",
        ".hh",
        ".hm",
        ".hpp",
        ".hxx",
        ".tcc",
        ".h++",
        ".H++",
        ".HPP",
        ".H",
    };
    return header_file_extensions;
}

const StringSet &getCSourceFileExtensions()
{
    static const StringSet c_source_file_extensions{
        ".c",
        // Objective-C
        ".m",
    };
    return c_source_file_extensions;
}

const StringSet &getCppSourceFileExtensions()
{
    static const StringSet cpp_source_file_extensions{
        ".cc",
        ".CC",
        ".cpp",
        ".cp",
        ".cxx",
        //".ixx", // msvc modules?
        // cppm - clang?
        // mxx, mpp - build2?
        ".c++",
        ".C++",
        ".CPP",
        ".CXX",
        ".C", // old ext (Wt, some gnu)
        // Objective-C
        ".mm",

        ".sw", // our special, to run .sw apps

        // msvc modules
        ".ixx",
    };
    return cpp_source_file_extensions;
}

void log_msg_detect_target(const String &m)
{
    LOG_TRACE(logger, m);
}

PredefinedProgramTarget &addProgram(DETECT_ARGS, const PackageId &id, const TargetSettings &ts, const std::shared_ptr<Program> &p)
{
    auto &t = addTarget<PredefinedProgramTarget>(DETECT_ARGS_PASS, id, ts);
    t.public_ts["output_file"] = to_string(normalize_path(p->file));
    t.setProgram(p);
    LOG_TRACE(logger, "Detected program: " + to_string(p->file.u8string()));
    return t;
}

bool isCppHeaderFileExtension(const String &e)
{
    auto &exts = getCppHeaderFileExtensions();
    return exts.find(e) != exts.end();
}

bool isCSourceFileExtensions(const String &e)
{
    auto &exts = getCSourceFileExtensions();
    return exts.find(e) != exts.end();
}

bool isCppSourceFileExtensions(const String &e)
{
    auto &exts = getCppSourceFileExtensions();
    return exts.find(e) != exts.end();
}

VSInstances &gatherVSInstances()
{
    static VSInstances instances = []()
    {
        VSInstances instances;
#ifdef _WIN32
        cmVSSetupAPIHelper h;
        h.EnumerateVSInstances();
        for (auto &i : h.instances)
        {
            path root = i.VSInstallLocation;
            Version v = to_string(i.Version);

            // actually, it does not affect cl.exe or other tool versions
            if (i.VSInstallLocation.find(L"Preview") != std::wstring::npos)
                v = v.toString() + "-preview";

            VSInstance inst;
            inst.root = root;
            inst.version = v;
            instances.emplace(v, inst);
        }
#endif
        return instances;
    }();
    return instances;
}

static bool detectMsvcCommon(const path &compiler, const Version &vs_version,
    ArchType target_arch, const path &host_root, const TargetSettings &ts, const path &idir,
    const path &root, const path &target,
    DETECT_ARGS)
{
    // VS programs inherit cl.exe version (V)
    // same for VS libs
    // because ml,ml64,lib,link version (O) has O.Major = V.Major - 5
    // e.g., V = 19.21..., O = 14.21.... (19 - 5 = 14)

    String msvc_prefix;
    Version cl_exe_version;
    const auto add_path_dir = s.getHostOs().Arch != target_arch || vs_version < Version(12);

    // C, C++
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = compiler / "cl.exe";
        if (!fs::exists(p->file))
        {
            LOG_TRACE(logger, "detectMsvcCommon: " << p->file << " does not exists");
            return false;
        }

        auto c = p->getCommand();
        if (add_path_dir)
            c->addPathDirectory(host_root);
        msvc_prefix = detectMsvcPrefix(*c);
        // run getVersion via prepared command
        builder::detail::ResolvableCommand c2 = *c;
        cl_exe_version = getVersion(s, c2);
        if (vs_version.isPreRelease())
            cl_exe_version.getExtra() = vs_version.getExtra();
        auto &cl = addProgram(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.cl", cl_exe_version), ts, p);

        // rule based msvc
        if (s.getHostOs().Arch == target_arch)
        {
            auto &t = addTarget<PredefinedTargetWithRule>(DETECT_ARGS_PASS, PackageId{"msvc", cl_exe_version}, ts);
            t.public_ts["output_file"] = to_string(normalize_path(p->file));
        }
    }

    // lib, link
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = compiler / "link.exe";
        if (fs::exists(p->file))
            addProgram(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.link", cl_exe_version), ts, p);

        if (add_path_dir)
        {
            auto c = p->getCommand();
            c->addPathDirectory(host_root);
        }

        p = std::make_shared<SimpleProgram>();
        p->file = compiler / "lib.exe";
        if (fs::exists(p->file))
            addProgram(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.lib", cl_exe_version), ts, p);

        if (add_path_dir)
        {
            auto c = p->getCommand();
            c->addPathDirectory(host_root);
        }
    }

    // ASM
    if (target_arch == ArchType::x86_64 || target_arch == ArchType::x86 || target_arch == ArchType::aarch64 || target_arch == ArchType::arm)
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = compiler / ((target_arch == ArchType::x86_64 || target_arch == ArchType::aarch64) ? "ml64.exe" : "ml.exe");
        if (fs::exists(p->file))
        {
            addProgram(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.ml", cl_exe_version), ts, p);
            getMsvcIncludePrefixes()[p->file] = msvc_prefix;
        }
    }

    // dumpbin
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = compiler / "dumpbin.exe";
        if (fs::exists(p->file))
            addProgram(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.dumpbin", cl_exe_version), ts, p);
        // should we add path dir here?
    }

    // libc++
    {
        auto &libcpp = addTarget<PredefinedTarget>(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.libcpp", cl_exe_version), ts);
        libcpp.public_ts["properties"]["6"]["system_include_directories"].push_back(idir);
        auto no_target_libdir = vs_version.getMajor() < 15 && target == "x86";
        if (no_target_libdir)
            libcpp.public_ts["properties"]["6"]["system_link_directories"].push_back(root / "lib");
        else
            libcpp.public_ts["properties"]["6"]["system_link_directories"].push_back(root / "lib" / target);
        if (cl_exe_version.getMajor() >= 19)
        {
            // under cond?
            libcpp.public_ts["properties"]["6"]["system_link_libraries"].push_back(boost::to_upper_copy("oldnames.lib"s));

            // 100% under cond
            libcpp.public_ts["properties"]["6"]["system_link_libraries"].push_back(boost::to_upper_copy("legacy_stdio_definitions.lib"s));
            libcpp.public_ts["properties"]["6"]["system_link_libraries"].push_back(boost::to_upper_copy("legacy_stdio_wide_specifiers.lib"s));
        }

        if (fs::exists(root / "ATLMFC" / "include"))
        {
            auto &atlmfc = addTarget<PredefinedTarget>(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.ATLMFC", cl_exe_version), ts);
            atlmfc.public_ts["properties"]["6"]["system_include_directories"].push_back(root / "ATLMFC" / "include");
            if (no_target_libdir)
                atlmfc.public_ts["properties"]["6"]["system_link_directories"].push_back(root / "ATLMFC" / "lib");
            else
                atlmfc.public_ts["properties"]["6"]["system_link_directories"].push_back(root / "ATLMFC" / "lib" / target);
            atlmfc.public_ts["properties"]["6"]["system_link_libraries"].push_back(boost::to_upper_copy("atls.lib"s));
        }

        if (fs::exists(root / "ifc"))
        {
            auto ts2 = ts;

            // release configs
            /*{
                auto &modules = addTarget<PredefinedTarget>(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.libcpp.modules", cl_exe_version), ts2);
                modules.public_ts["properties"]["6"]["system_link_directories"].push_back(root / "ifc" / target / "Release");
                modules.public_ts["properties"]["6"]["system_link_libraries"].push_back(boost::to_upper_copy("std.lib"s));
            }

            // debug
            {
                ts2["native"]["configuration"] = "debug";
                auto &modules = addTarget<PredefinedTarget>(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.libcpp.modules", cl_exe_version), ts2);
                modules.public_ts["properties"]["6"]["system_link_directories"].push_back(root / "ifc" / target / "Debug");
                modules.public_ts["properties"]["6"]["system_link_libraries"].push_back(boost::to_upper_copy("std.lib"s));
            }*/
        }
    }

    if (cl_exe_version.getMajor() >= 19)
    {
        // concrt
        if (fs::exists(root / "crt" / "src" / "concrt"))
        {
            auto &libcpp = addTarget<PredefinedTarget>(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.concrt", cl_exe_version), ts);
            libcpp.public_ts["properties"]["6"]["system_include_directories"].push_back(root / "crt" / "src" / "concrt");
        }

        // vcruntime
        if (fs::exists(root / "crt" / "src" / "vcruntime"))
        {
            auto &libcpp = addTarget<PredefinedTarget>(DETECT_ARGS_PASS, PackageId("com.Microsoft.VisualStudio.VC.runtime", cl_exe_version), ts);
            libcpp.public_ts["properties"]["6"]["system_include_directories"].push_back(root / "crt" / "src" / "vcruntime");
        }
    }

    return true;
}

void detectMsvc15Plus(DETECT_ARGS)
{
    // https://docs.microsoft.com/en-us/cpp/c-runtime-library/crt-library-features?view=vs-2019

    auto &instances = gatherVSInstances();
    const auto host = toStringWindows(s.getHostOs().Arch);
    auto new_settings = s.getHostOs();

    for (auto target_arch : {ArchType::x86_64,ArchType::x86,ArchType::arm,ArchType::aarch64})
    {
        new_settings.Arch = target_arch;

        auto ts1 = toTargetSettings(new_settings);
        TargetSettings ts;
        ts["os"]["kernel"] = ts1["os"]["kernel"];
        ts["os"]["arch"] = ts1["os"]["arch"];

        for (auto &[_, instance] : instances)
        {
            auto root = instance.root / "VC";
            auto v = instance.version;

            if (v.getMajor() < 15)
            {
                // continue; // instead of throw ?
                throw SW_RUNTIME_ERROR("VS < 15 must be handled differently");
            }

            root = root / "Tools" / "MSVC" / boost::trim_copy(read_file(root / "Auxiliary" / "Build" / "Microsoft.VCToolsVersion.default.txt"));
            auto idir = root / "include";

            // get suffix
            auto target = toStringWindows(target_arch);

            auto compiler = root / "bin";
            auto host_root = compiler / ("Host" + host) / host;

            compiler /= path("Host" + host) / target;

            detectMsvcCommon(compiler, v, target_arch, host_root, ts, idir, root, target, DETECT_ARGS_PASS);
        }
    }
}

void detectMsvc14AndOlder(DETECT_ARGS)
{
    LOG_TRACE(logger, "Detecting msvc 14 and older");

    auto find_comn_tools = [](const Version &v) -> path
    {
        auto n = std::to_string(v.getMajor()) + std::to_string(v.getMinor());
        auto ver = "VS"s + n + "COMNTOOLS";
        auto e = getenv(ver.c_str());
        if (!e)
            return {};

        LOG_TRACE(logger, "Found " << ver << "=" << e);

        String r = e;
        while (!r.empty() && (r.back() == '/' || r.back() == '\\'))
            r.pop_back();
        path root = r;
        root = root.parent_path().parent_path();

        LOG_TRACE(logger, "Use " << ver << " as " << root);

        return root;
    };

    auto toStringWindows14AndOlder = [](ArchType e)
    {
        switch (e)
        {
        case ArchType::x86_64:
            return "amd64";
        case ArchType::x86:
            return "x86";
        case ArchType::arm:
            return "arm";
        default:
            throw SW_RUNTIME_ERROR("Unknown Windows arch");
        }
    };

    auto new_settings = s.getHostOs();

    for (auto n : {14,12,11,10,9,8})
    {
        const Version vs_version(n);
        const auto vsroot = find_comn_tools(vs_version);
        if (vsroot.empty())
            continue;

        //
        auto root = vsroot / "VC";
        auto bindir = root / "bin";
        auto idir = root / "include";

        bool found = false;
        // no ArchType::aarch64?
        for (auto target_arch : { ArchType::x86_64,ArchType::x86,ArchType::arm, })
        {
            // following code is written using VS2015
            // older versions might need special handling

            new_settings.Arch = target_arch;

            auto ts1 = toTargetSettings(new_settings);
            TargetSettings ts;
            ts["os"]["kernel"] = ts1["os"]["kernel"];
            ts["os"]["arch"] = ts1["os"]["arch"];

            // get suffix
            auto target = toStringWindows14AndOlder(target_arch);

            auto compiler = bindir;
            auto host_root = compiler;

            path libdir = toStringWindows14AndOlder(target_arch);

            // VC/bin/ ... x86 files
            // VC/bin/amd64/ ... x86_64 files
            // VC/bin/arm/ ... arm files
            // so we need to add subdir for non x86 targets
            if (!s.getHostOs().is(ArchType::x86))
            {
                host_root /= toStringWindows14AndOlder(s.getHostOs().Arch);
            }

            // now set to root
            compiler = host_root;

            // VC/bin/x86_amd64
            // VC/bin/x86_arm
            // VC/bin/amd64_x86
            // VC/bin/amd64_arm
            if (s.getHostOs().Arch != target_arch)
            {
                //if (!s.getHostOs().is(ArchType::x86))
                compiler += "_"s + toStringWindows14AndOlder(target_arch);
            }

            // VS 11.0 has cl.exe 17.x
            // it stores required dlls in other dir than host root
            // VS11.0: 'C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE'
            //LOG_TRACE(logger, "vs version = " << vs_version.toString());
            if (vs_version < Version(12))
                host_root = vsroot / "Common7" / "IDE";
            //LOG_TRACE(logger, "host_root = " << host_root);

            // VS programs inherit cl.exe version (V)
            // same for VS libs
            // because ml,ml64,lib,link version (O) has O.Major = V.Major - 5
            // e.g., V = 19.21..., O = 14.21.... (19 - 5 = 14)

            found |= detectMsvcCommon(compiler, vs_version, target_arch, host_root, ts, idir, root, libdir, DETECT_ARGS_PASS);
        }

        if (found)
            continue;

        LOG_TRACE(logger, "Default VS2015 paths were not found. Trying older versions layout.");

        // some VS14 (VS2015 release or early updates) (probably older VS too) does not have amd64_ dirs
        // so we check bin/cl.exe, x86_amd64/cl.exe, x86_arm/cl.exe

        for (auto target_arch : { ArchType::x86_64,ArchType::x86 })
        {
            new_settings.Arch = target_arch;

            auto ts1 = toTargetSettings(new_settings);
            TargetSettings ts;
            ts["os"]["kernel"] = ts1["os"]["kernel"];
            ts["os"]["arch"] = ts1["os"]["arch"];

            auto compiler = bindir;
            auto host_root = compiler;
            path libdir = toStringWindows14AndOlder(target_arch);
            // for x64 we check only x86_amd64 dir
            if (target_arch == ArchType::x86_64)
                compiler /= "x86_"s + toStringWindows14AndOlder(target_arch);

            // VS 11.0 has cl.exe 17.x
            // it stores required dlls in other dir than host root
            // VS11.0: 'C:\Program Files (x86)\Microsoft Visual Studio 11.0\Common7\IDE'
            //LOG_TRACE(logger, "vs version = " << vs_version.toString());
            if (vs_version < Version(12))
                host_root = vsroot / "Common7" / "IDE";
            //LOG_TRACE(logger, "host_root = " << host_root);

            detectMsvcCommon(compiler, vs_version, target_arch, host_root, ts, idir, root, libdir, DETECT_ARGS_PASS);
        }
    }
}

void detectWindowsSdk(DETECT_ARGS);

static void detectMsvc(DETECT_ARGS)
{
    detectMsvc15Plus(DETECT_ARGS_PASS);
    detectMsvc14AndOlder(DETECT_ARGS_PASS);
    detectWindowsSdk(DETECT_ARGS_PASS);
}

static bool hasConsoleColorProcessing()
{
#ifdef _WIN32
    bool r = false;
    DWORD mode;
    // Try enabling ANSI escape sequence support on Windows 10 terminals.
    auto console_ = GetStdHandle(STD_OUTPUT_HANDLE);
    if (GetConsoleMode(console_, &mode))
        r |= (bool)(mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    console_ = GetStdHandle(STD_ERROR_HANDLE);
    if (GetConsoleMode(console_, &mode))
        r &= (bool)(mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    return r;
#endif
    return true;
}

static void detectWindowsClang(DETECT_ARGS, const path &base_llvm_path)
{
    // create programs
    const path bin_llvm_path = base_llvm_path / "bin";

    bool colored_output = hasConsoleColorProcessing();

    // clang-cl, move to msvc?

    // C, C++
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = bin_llvm_path / "clang-cl.exe";
        //C->file = base_llvm_path / "msbuild-bin" / "cl.exe";
        if (!fs::exists(p->file))
        {
            auto f = resolveExecutable("clang-cl");
            if (fs::exists(f))
                p->file = f;
        }
        if (fs::exists(p->file))
        {
            auto cmd = p->getCommand();
            auto msvc_prefix = detectMsvcPrefix(*cmd);
            getMsvcIncludePrefixes()[p->file] = msvc_prefix;

            auto [o,v] = getVersionAndOutput(s, p->file);

            // check before adding target
            static std::regex r("InstalledDir: (.*)\\r?\\n?");
            std::smatch m;
            if (std::regex_search(o, m, r))
            {
                auto &c = addProgram(DETECT_ARGS_PASS, PackageId("org.LLVM.clangcl", v), {}, p);

                auto c2 = p->getCommand();
                //c2->push_back("-X"); // prevents include dirs autodetection
                // we use --nostdinc, so -X is not needed
                if (colored_output)
                {
                    //c2->push_back("-Xclang").affects_output = false;
                    //c2->push_back("-fcolor-diagnostics").affects_output = false;
                    //c2->push_back("-Xclang").affects_output = false;
                    //c2->push_back("-fansi-escape-codes").affects_output = false;
                }

                // returns path to /bin dir
                path dir = m[1].str();
                dir = dir.parent_path() / "lib/clang" / v.toString() / "include";
                auto s = to_string(normalize_path(dir));
                auto arg = std::make_unique<primitives::command::SimplePositionalArgument>("-I" + s);
                arg->getPosition().push_back(150);
                c2->push_back(std::move(arg));
            }
            else
            {
                LOG_ERROR(logger, "Cannot get clang-cl installed dir (InstalledDir): " + o);
            }
        }
    }

    // clang

    // link
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = bin_llvm_path / "lld.exe";
        if (!fs::exists(p->file))
        {
            auto f = resolveExecutable("lld");
            if (fs::exists(f))
                p->file = f;
        }
        if (fs::exists(p->file))
        {
            auto v = getVersion(s, p->file);
            addProgram(DETECT_ARGS_PASS, PackageId("org.LLVM.lld", v), {}, p);
        }
    }

    // lld-link
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = bin_llvm_path / "lld-link.exe";
        if (!fs::exists(p->file))
        {
            auto f = resolveExecutable("lld-link");
            if (fs::exists(f))
                p->file = f;
        }
        if (fs::exists(p->file))
        {
            auto v = getVersion(s, p->file);
            addProgram(DETECT_ARGS_PASS, PackageId("org.LLVM.lld.link", v), {}, p);

            auto c2 = p->getCommand();
            c2->push_back("-lldignoreenv"); // prevents libs dirs autodetection (from msvc)
        }
    }

    // ar
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = bin_llvm_path / "llvm-ar.exe";
        if (!fs::exists(p->file))
        {
            auto f = resolveExecutable("llvm-ar");
            if (fs::exists(f))
                p->file = f;
        }
        if (fs::exists(p->file))
        {
            auto v = getVersion(s, p->file);
            addProgram(DETECT_ARGS_PASS, PackageId("org.LLVM.ar", v), {}, p);
        }
    }

    // C
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = bin_llvm_path / "clang.exe";
        if (!fs::exists(p->file))
        {
            auto f = resolveExecutable("clang");
            if (fs::exists(f))
                p->file = f;
        }
        if (fs::exists(p->file))
        {
            auto v = getVersion(s, p->file);
            addProgram(DETECT_ARGS_PASS, PackageId("org.LLVM.clang", v), {}, p);

            if (colored_output)
            {
                auto c2 = p->getCommand();
                //c2->push_back("-fcolor-diagnostics").affects_output = false;
                //c2->push_back("-fansi-escape-codes").affects_output = false;
            }
            //c->push_back("-Wno-everything");
            // is it able to find VC STL itself?
            //COpts2.System.IncludeDirectories.insert(base_llvm_path / "lib" / "clang" / C->getVersion().toString() / "include");
        }
    }

    // C++
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = bin_llvm_path / "clang++.exe";
        if (!fs::exists(p->file))
        {
            auto f = resolveExecutable("clang++");
            if (fs::exists(f))
                p->file = f;
        }
        if (fs::exists(p->file))
        {
            auto v = getVersion(s, p->file);
            auto &c = addProgram(DETECT_ARGS_PASS, PackageId("org.LLVM.clangpp", v), {}, p);

            if (colored_output)
            {
                auto c2 = p->getCommand();
                //c2->push_back("-fcolor-diagnostics").affects_output = false;
                //c2->push_back("-fansi-escape-codes").affects_output = false;
            }
            //c->push_back("-Wno-everything");
            // is it able to find VC STL itself?
            //COpts2.System.IncludeDirectories.insert(base_llvm_path / "lib" / "clang" / C->getVersion().toString() / "include");
        }
    }
}

static void detectWindowsClang(DETECT_ARGS)
{
    detectWindowsClang(DETECT_ARGS_PASS, path{"C:/Program Files/LLVM"});

    auto &instances = gatherVSInstances();
    auto host = toStringWindows(s.getHostOs().Arch);
    if (s.getHostOs().Arch == ArchType::x86)
    {
        host = ".";
    }
    for (auto &[_, instance] : instances)
    {
        auto root = instance.root / "VC";
        auto v = instance.version;

        if (v.getMajor() < 15)
        {
            continue;
        }

        root = root / "Tools" / "Llvm" / host;
        detectWindowsClang(DETECT_ARGS_PASS, root);
    }
}

static void detectIntelCompilers(DETECT_ARGS)
{
    // some info at https://gitlab.com/ita1024/waf/blob/master/waflib/Tools/msvc.py#L521

    // C, C++

    // win
    {
        auto add_prog_from_path = [DETECT_ARGS_PASS_TO_LAMBDA](const path &name, const String &ppath)
        {
            auto p = std::make_shared<SimpleProgram>();
            p->file = resolveExecutable(name);
            if (fs::exists(p->file))
            {
                auto v = getVersion(s, p->file);
                addProgram(DETECT_ARGS_PASS, PackageId(ppath, v), {}, p);

                // icl/xilib/xilink on win wants VC in PATH
                auto &cld = s.getPredefinedTargets();
                auto i = cld["com.Microsoft.VisualStudio.VC.cl"].rbegin_releases();
                if (i != cld["com.Microsoft.VisualStudio.VC.cl"].rend_releases())
                {
                    if (!i->second.empty())
                    {
                        if (auto t = (*i->second.begin())->as<PredefinedProgramTarget *>())
                        {
                            path x = t->getProgram().getCommand()->getProgram();
                            p->getCommand()->addPathDirectory(x.parent_path());
                        }
                    }
                }
            }
            return p;
        };

        add_prog_from_path("icl", "com.intel.compiler.c");
        add_prog_from_path("icl", "com.intel.compiler.cpp");
        add_prog_from_path("xilib", "com.intel.compiler.lib");
        add_prog_from_path("xilink", "com.intel.compiler.link");

        // ICPP_COMPILER{VERSION} like ICPP_COMPILER19 etc.
        for (int i = 9; i < 23; i++)
        {
            auto s = "ICPP_COMPILER" + std::to_string(i);
            auto v = getenv(s.c_str());
            if (!v)
                continue;

            path root = v;
            auto bin = root;
            bin /= "bin";
            auto arch = "intel64";
            bin /= arch;

            std::shared_ptr<SimpleProgram> p;
            p = add_prog_from_path(bin / "icl", "com.intel.compiler.c");
            p->getCommand()->push_back("-I");
            p->getCommand()->push_back(root / "compiler" / "include");

            p = add_prog_from_path(bin / "icl", "com.intel.compiler.cpp");
            p->getCommand()->push_back("-I");
            p->getCommand()->push_back(root / "compiler" / "include");

            add_prog_from_path(bin / "xilib", "com.intel.compiler.lib");

            p = add_prog_from_path(bin / "xilink", "com.intel.compiler.link");
            p->getCommand()->push_back("-LIBPATH:" + to_string((root / "compiler" / "lib" / arch).u8string()));
            p->getCommand()->push_back("libirc.lib");
        }

        // also registry paths
        // HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Intel ...
    }

    // *nix
    {
        {
            auto p = std::make_shared<SimpleProgram>(); // new object
            p->file = resolveExecutable("icc");
            if (fs::exists(p->file))
            {
                auto v = getVersion(s, p->file);
                addProgram(DETECT_ARGS_PASS, PackageId("com.intel.compiler.c", v), {}, p);
            }
        }

        {
            auto p = std::make_shared<SimpleProgram>(); // new object
            p->file = resolveExecutable("icpc");
            if (fs::exists(p->file))
            {
                auto v = getVersion(s, p->file);
                addProgram(DETECT_ARGS_PASS, PackageId("com.intel.compiler.cpp", v), {}, p);
            }
        }
    }
}

static void detectWindowsCompilers(DETECT_ARGS)
{
    detectMsvc(DETECT_ARGS_PASS);
    detectWindowsClang(DETECT_ARGS_PASS);
}

auto add_dummy_windows_targets(auto &&s, auto &&tm) {
    auto add_dummy_target = [&](auto &&name) {
        auto cl = s.getPredefinedTargets().find(name);
        if (cl == s.getPredefinedTargets().end(name)) {
            //LOG_INFO(logger, "adding dummy winrt targets");

            TargetSettings ts{};
            sw::addTarget<sw::PredefinedTarget>(DETECT_ARGS_PASS, sw::LocalPackage(s.getLocalStorage(), sw::PackageId(name, "0.0.1")), ts);

            auto ts1 = toTargetSettings(s.getHostOs());
            ts["os"]["kernel"] = ts1["os"]["kernel"];
            ts["os"]["arch"] = ts1["os"]["arch"];
            sw::addTarget<sw::PredefinedTarget>(DETECT_ARGS_PASS, sw::LocalPackage(s.getLocalStorage(), sw::PackageId(name, "0.0.1")), ts);
        }
        auto cl2 = s.getPredefinedTargets().find(name);
        if (cl2 != s.getPredefinedTargets().end(name)) {
            //LOG_INFO(logger, "added dummy winrt targets");
        }
    };
    add_dummy_target("com.Microsoft.Windows.SDK.winrt");
    add_dummy_target("com.Microsoft.Windows.SDK.cppwinrt");
}

static void detectNonWindowsCompilers(DETECT_ARGS, bool quick_gcc)
{
    bool colored_output = hasConsoleColorProcessing();

    auto resolve_and_add = [DETECT_ARGS_PASS_TO_LAMBDA, &colored_output]
        (const path &prog, const String &ppath, int color_diag = 0, const String &regex_prefix = {})
    {
        auto p = std::make_shared<SimpleProgram>();
        p->file = resolveExecutable(prog);
        if (!fs::exists(p->file))
            return false;
        // use simple regex for now, because ubuntu may have
        // the following version 7.4.0-1ubuntu1~18.04.1
        // which will be parsed as pre-release
        auto [o,v] = getVersionAndOutput(s, p->file, "--version", regex_prefix + "\\d+(\\.\\d+){2,}");
        auto &c = addProgram(DETECT_ARGS_PASS, PackageId(ppath, v), {}, p);
        //-fdiagnostics-color=always // gcc
        if (colored_output)
        {
            auto c2 = p->getCommand();
            if (color_diag == 1)
                c2->push_back("-fdiagnostics-color=always").affects_output = false;
            else if (color_diag == 2)
            {
                //c2->push_back("-fcolor-diagnostics").affects_output = false;
                //c2->push_back("-fansi-escape-codes").affects_output = false;
            }
        }
        return true;
    };

    resolve_and_add("ar", "org.gnu.binutils.ar");
    resolve_and_add("llvm-ar", "org.gnu.binutils.ar");
    //resolve_and_add("as", "org.gnu.gcc.as"); // not needed
    //resolve_and_add("ld", "org.gnu.gcc.ld"); // not needed

    auto resolve_gcc = [&](path prog, auto &&ppath, auto &&color_diag) {
        try {
            prog = resolveExecutable(prog);
            if (!fs::exists(prog)) {
                return;
            }
            auto [o,v] = gatherVersion(prog, "--version", "\\d+(\\.\\d+){2,}");
            //LOG_TRACE(logger, "gcc resolver 1: " << v.toString());
            if (o.contains("Apple clang version")) {
                return;
            }
            //LOG_TRACE(logger, "gcc resolver: " << v.toString());
            auto p = std::make_shared<SimpleProgram>();
            p->file = prog;
            auto &c = addProgram(DETECT_ARGS_PASS, PackageId(ppath, v), {}, p);
            //-fdiagnostics-color=always // gcc
            if (colored_output)
            {
                auto c2 = p->getCommand();
                if (color_diag == 1)
                    c2->push_back("-fdiagnostics-color=always").affects_output = false;
                else if (color_diag == 2)
                {
                    //c2->push_back("-fcolor-diagnostics").affects_output = false;
                    //c2->push_back("-fansi-escape-codes").affects_output = false;
                }
            }
        } catch (std::exception &) {
        }
    };

    resolve_gcc("gcc", "org.gnu.gcc", 1);
    resolve_gcc("g++", "org.gnu.gpp", 1);

    if (quick_gcc) {
        return;
    }

    // 14=2024, 20=2030
    for (int i = 3; i < 20; i++)
    {
        resolve_gcc("gcc-" + std::to_string(i), "org.gnu.gcc", 1);
        resolve_gcc("g++-" + std::to_string(i), "org.gnu.gpp", 1);
    }

    // llvm/clang
    //resolve_and_add("llvm-ar", "org.LLVM.ar"); // not needed
    //resolve_and_add("lld", "org.LLVM.ld"); // not needed

    // start of the line (^) does not work currently,
    // so we can't differentiate clang and appleclang
    auto clang_regex_prefix = "^clang version ";
    auto homebrew_clang_regex_prefix = "Homebrew clang version ";
    auto apple_clang_regex_prefix = "Apple clang version ";

    auto resolve_clang = [&](path prog, auto &&ppath, auto &&color_diag, bool apple = false) {
        try {
            prog = resolveExecutable(prog);
            if (!fs::exists(prog)) {
                return;
            }
            auto [o,v] = gatherVersion(prog, "--version", "\\d+(\\.\\d+){2,}");
            //LOG_TRACE(logger, "clang resolver 1: " << v.toString());
            if (o.contains("Apple clang version")) {
                if (!apple) {
                    return;
                }
                auto p = std::make_shared<SimpleProgram>();
                p->file = prog;
                auto &c = addProgram(DETECT_ARGS_PASS, PackageId(ppath, v), {}, p);
                //-fdiagnostics-color=always // gcc
                if (colored_output)
                {
                    auto c2 = p->getCommand();
                    if (color_diag == 1)
                        c2->push_back("-fdiagnostics-color=always").affects_output = false;
                    else if (color_diag == 2)
                    {
                        //c2->push_back("-fcolor-diagnostics").affects_output = false;
                        //c2->push_back("-fansi-escape-codes").affects_output = false;
                    }
                }
                return;
            }
            if (apple) {
                return;
            }
            //LOG_TRACE(logger, "clang resolver 2: " << v.toString());
            // check homebrew first
            if (o.starts_with(homebrew_clang_regex_prefix)) {
                //LOG_TRACE(logger, "clang resolver: " << v.toString());
                auto p = std::make_shared<SimpleProgram>();
                p->file = prog;
                auto &c = addProgram(DETECT_ARGS_PASS, PackageId(ppath, v), {}, p);
                //-fdiagnostics-color=always // gcc
                if (colored_output)
                {
                    auto c2 = p->getCommand();
                    if (color_diag == 1)
                        c2->push_back("-fdiagnostics-color=always").affects_output = false;
                    else if (color_diag == 2)
                    {
                        //c2->push_back("-fcolor-diagnostics").affects_output = false;
                        //c2->push_back("-fansi-escape-codes").affects_output = false;
                    }
                }
                return;
            }
            if (o.contains("clang version")) {
                //LOG_TRACE(logger, "clang resolver: " << v.toString());
                auto p = std::make_shared<SimpleProgram>();
                p->file = prog;
                auto &c = addProgram(DETECT_ARGS_PASS, PackageId(ppath, v), {}, p);
                //-fdiagnostics-color=always // gcc
                if (colored_output)
                {
                    auto c2 = p->getCommand();
                    if (color_diag == 1)
                        c2->push_back("-fdiagnostics-color=always").affects_output = false;
                    else if (color_diag == 2)
                    {
                        //c2->push_back("-fcolor-diagnostics").affects_output = false;
                        //c2->push_back("-fansi-escape-codes").affects_output = false;
                    }
                }
                return;
            }
        } catch (std::exception &) {
        }
    };

    // detect apple clang, the single version in the system
    resolve_clang("clang", "com.Apple.clang", 2, true);
    resolve_clang("clang++", "com.Apple.clangpp", 2, true);
    // we may totally fail above and without apple clang we can't even build sw.cpp
    // so check direct paths
    resolve_clang("/usr/bin/clang", "com.Apple.clang", 2, true);
    resolve_clang("/usr/bin/clang++", "com.Apple.clangpp", 2, true);

    // usual clang
    resolve_clang("clang", "org.LLVM.clang", 2);
    resolve_clang("clang++", "org.LLVM.clangpp", 2);

    // 18,19=2024 34,35=2030+
    for (int i = 3; i < 35; i++)
    {
        resolve_clang("clang-" + std::to_string(i), "org.LLVM.clang", 2);
        resolve_clang("clang++-" + std::to_string(i), "org.LLVM.clangpp", 2);
    }

#ifndef _WIN32
    //add_dummy_windows_targets(DETECT_ARGS_PASS);
#endif
}

void detectNativeCompilers(DETECT_ARGS)
{
    auto &os = s.getHostOs();
    if (os.is(OSType::Windows) || os.is(OSType::Cygwin) || os.is(OSType::Mingw))
    {
        // we should pass target settings here and check according target os (cygwin)
        if (os.is(OSType::Cygwin) || os.is(OSType::Mingw) || os.isMingwShell())
            detectNonWindowsCompilers(DETECT_ARGS_PASS, false);
        else
            detectNonWindowsCompilers(DETECT_ARGS_PASS, true);
        detectWindowsCompilers(DETECT_ARGS_PASS);
    }
    else
        detectNonWindowsCompilers(DETECT_ARGS_PASS, false);
    detectIntelCompilers(DETECT_ARGS_PASS);
}

void detectProgramsAndLibraries(DETECT_ARGS)
{
#define DETECT(x) detect##x##Compilers(DETECT_ARGS_PASS);
#include "detect.inl"
#undef DETECT
}

// actually we cannot move this to client,
// because we support different languages and packages
// scripting languages do not have os, arch, kernel, configuration etc.
static void addSettings(TargetSettings &ts, bool force)
{
    auto check_and_assign = [force](auto &k, const auto &v)
    {
        if (force || !k)
            k = v;
    };

    // settings
    check_and_assign(ts["native"]["configuration"], "release");
    check_and_assign(ts["native"]["library"], "shared");
    check_and_assign(ts["native"]["mt"], "false");
}

// remember! only host tools
// they must be the same as used when building sw
void addSettingsAndSetHostPrograms(const SwCoreContext &swctx, TargetSettings &ts)
{
    addSettings(ts, true);

    auto to_upkg = [](const auto &s)
    {
        return UnresolvedPackage(s).toString();
    };

    // deps: programs, stdlib etc.
    auto check_and_assign_dependency = [&swctx, &ts](auto &k, const auto &v, int version_level = 0)
    {
        auto check_and_assign = [](auto &k, const auto &v)
        {
            k = v;
        };

        auto i = swctx.getPredefinedTargets().find(UnresolvedPackage(v), ts);
        if (i)
            check_and_assign(k, version_level ? i->getPackage().toString(version_level) : i->getPackage().toString());
        else
            check_and_assign(k, v);
    };

    if (swctx.getHostOs().Type == OSType::Windows)
    {
        check_and_assign_dependency(ts["native"]["stdlib"]["c"], to_upkg("com.Microsoft.Windows.SDK.ucrt"));
        check_and_assign_dependency(ts["native"]["stdlib"]["cpp"], to_upkg("com.Microsoft.VisualStudio.VC.libcpp"));
        //check_and_assign_dependency(ts["native"]["stdlib"]["cpp_modules"], to_upkg("com.Microsoft.VisualStudio.VC.libcpp.modules"));
        check_and_assign_dependency(ts["native"]["stdlib"]["kernel"], to_upkg("com.Microsoft.Windows.SDK.um"));

        // now find the latest available sdk (ucrt) and select it
        //TargetSettings oss;
        //oss["os"] = ts["os"];
        //auto sdk = swctx.getPredefinedTargets().find(UnresolvedPackage(ts["native"]["stdlib"]["c"].getValue()), oss);
        //if (!sdk)
            //throw SW_RUNTIME_ERROR("No suitable installed WinSDK found for this host");
        //ts["native"]["stdlib"]["c"] = sdk->getPackage().toString(); // assign always
        //ts["os"]["version"] = sdkver->toString(3); // cut off the last (fourth) number

        auto clpkg = "com.Microsoft.VisualStudio.VC.cl";
        auto cl = swctx.getPredefinedTargets().find(clpkg);

        auto clangpppkg = "org.LLVM.clangpp";
        auto clangpp = swctx.getPredefinedTargets().find(clpkg);

        auto clangclpkg = "org.LLVM.clangcl";
        auto clangcl = swctx.getPredefinedTargets().find(clangclpkg);

        if (0)
        {
        }
#ifdef _MSC_VER
        // msvc
        else if (cl != swctx.getPredefinedTargets().end(clpkg) && !cl->second.empty())
        {
            check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("com.Microsoft.VisualStudio.VC.cl"));
            check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("com.Microsoft.VisualStudio.VC.cl"));
            check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("com.Microsoft.VisualStudio.VC.ml"));
            check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("com.Microsoft.VisualStudio.VC.lib"));
            check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("com.Microsoft.VisualStudio.VC.link"));
        }
#endif
        // we can't activate host clangcl because we need to distribute these new binaries
        // and not every system has clang
#if defined(__clang__) && defined(_MSC_VER)
        // clangcl is in charge now!
        else if (clangcl != swctx.getPredefinedTargets().end(clangclpkg) && !clangcl->second.empty())
        {
            check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("org.LLVM.clangcl"));
            check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("org.LLVM.clangcl"));
            check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("org.LLVM.clangcl"));
            // ?
            check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("com.Microsoft.VisualStudio.VC.lib"));
            check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("com.Microsoft.VisualStudio.VC.link"));
        }
#endif
#ifdef __clang__
        else if (clangpp != swctx.getPredefinedTargets().end(clangpppkg) && !clangpp->second.empty())
        {
            check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("org.LLVM.clang"));
            check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("org.LLVM.clangpp"));
            check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("org.LLVM.clang"));
            // ?
            check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("com.Microsoft.VisualStudio.VC.lib"));
            check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("com.Microsoft.VisualStudio.VC.link"));
        }
#endif
        else
        {
            throw SW_RUNTIME_ERROR("Seems like you do not have Visual Studio installed.\nPlease, install the latest Visual Studio first.");
        }
    }
    // add more defaults
    else
    {
        // set default libs?
        /*ts["native"]["stdlib"]["c"] = to_upkg("com.Microsoft.Windows.SDK.ucrt");
        ts["native"]["stdlib"]["cpp"] = to_upkg("com.Microsoft.VisualStudio.VC.libcpp");
        ts["native"]["stdlib"]["kernel"] = to_upkg("com.Microsoft.Windows.SDK.um");*/

        auto if_add = [&swctx, &check_and_assign_dependency](auto &s, const UnresolvedPackage &name)
        {
            auto &pd = swctx.getPredefinedTargets();
            auto i = pd.find(name);
            if (i == pd.end() || i->second.empty())
                return false;
            check_and_assign_dependency(s, name.toString());
            return true;
        };

        auto err_msg = [](const String &cl)
        {
            return "sw was built with " + cl + " as compiler, but it was not found in your system. Install " + cl + " to proceed.";
        };

        // must be the same compiler as current!
#if defined(__clang__)
        bool ok = false;
        if (!(
            if_add(ts["native"]["program"]["c"], "com.Apple.clang"s) &&
            if_add(ts["native"]["program"]["cpp"], "com.Apple.clangpp"s)
            ))
        {
            // no error, we want to check second condition
            //throw SW_RUNTIME_ERROR(err_msg("appleclang"));
        }
        else
            ok = true;
        if (!ok && !(
            if_add(ts["native"]["program"]["c"], "org.LLVM.clang"s) &&
            if_add(ts["native"]["program"]["cpp"], "org.LLVM.clangpp"s)
            ))
        {
            throw SW_RUNTIME_ERROR(err_msg("clang"));
        }
        //if (getHostOs().is(OSType::Linux))
        //ts["native"]["stdlib"]["cpp"] = to_upkg("org.sw.demo.llvm_project.libcxx");
#elif defined(__GNUC__) || defined(__CYGWIN__)
        if (!(
            if_add(ts["native"]["program"]["c"], "org.gnu.gcc"s) &&
            if_add(ts["native"]["program"]["cpp"], "org.gnu.gpp"s)
            ))
        {
            throw SW_RUNTIME_ERROR(err_msg("gcc"));
        }
#elif defined(_WIN32)
#else
#error "Add your current compiler to detect.cpp and here."
#endif

        // using c prog
        if (ts["native"]["program"]["c"].isValue())
            if_add(ts["native"]["program"]["asm"], ts["native"]["program"]["c"].getValue());

        // reconsider, also with driver?
        check_and_assign_dependency(ts["native"]["program"]["lib"], "org.gnu.binutils.ar"s);

        // use driver
        // use cpp driver for the moment to not burden ourselves in adding stdlib
        if (ts["native"]["program"]["cpp"].isValue())
            if_add(ts["native"]["program"]["link"], ts["native"]["program"]["cpp"].getValue());
    }

#ifdef __APPLE__
    check_and_assign_dependency(ts["native"]["program"]["m"], to_upkg("com.Apple.clang"));
    check_and_assign_dependency(ts["native"]["program"]["mm"], to_upkg("com.Apple.clangpp"));
#endif
}

//
void addSettingsAndSetPrograms(const SwCoreContext &swctx, TargetSettings &ts)
{
    addSettings(ts, false);

    auto to_upkg = [](const auto &s)
    {
        return UnresolvedPackage(s).toString();
    };

    // deps: programs, stdlib etc.
    // returns true if provided dependency (variable v) is set
    // if k is set and choosen over v, returns false
    auto check_and_assign_dependency = [&swctx, &ts](auto &k, const auto &v, int version_level = 0)
    {
        auto check_and_assign = [](auto &k, const auto &v, bool force2 = false)
        {
            if (!k || force2)
                k = v;
        };

        bool use_k = k && k.isValue();
        auto i = swctx.getPredefinedTargets().find(UnresolvedPackage(use_k ? k.getValue() : v), ts);
        if (i) {
            check_and_assign(k, version_level ? i->getPackage().toString(version_level) : i->getPackage().toString(), use_k);
            if (use_k) {
                auto i2 = swctx.getPredefinedTargets().find(UnresolvedPackage(v), ts);
                return i == i2;
            }
            return true;
        } else {
            check_and_assign(k, v);
            return true;
        }
    };

    BuildSettings bs(ts);
    // on win we select msvc, clang, clangcl
    if (bs.TargetOS.is(OSType::Windows))
    {
        //if (!ts["native"]["program"]["c"] || ts["native"]["program"]["c"].isValue())
        String sver;
        if (bs.TargetOS.Version)
            sver = "-" + bs.TargetOS.Version->toString();

        auto add_stdlib = [&]() {
            check_and_assign_dependency(ts["native"]["stdlib"]["c"], to_upkg("com.Microsoft.Windows.SDK.ucrt" + sver));
            check_and_assign_dependency(ts["native"]["stdlib"]["cpp"], to_upkg("com.Microsoft.VisualStudio.VC.libcpp"));
            //check_and_assign_dependency(ts["native"]["stdlib"]["cpp_modules"], to_upkg("com.Microsoft.VisualStudio.VC.libcpp.modules"));
            check_and_assign_dependency(ts["native"]["stdlib"]["kernel"], to_upkg("com.Microsoft.Windows.SDK.um" + sver));
        };

        // now find the latest available sdk (ucrt) and select it
        //TargetSettings oss;
        //oss["os"] = ts["os"];
        //auto sdk = swctx.getPredefinedTargets().find(UnresolvedPackage(ts["native"]["stdlib"]["c"].getValue()), oss);
        //if (!sdk)
        //throw SW_RUNTIME_ERROR("No suitable installed WinSDK found for this host");
        //ts["native"]["stdlib"]["c"] = sdk->getPackage().toString(); // assign always
        //ts["os"]["version"] = sdkver->toString(3); // cut off the last (fourth) number

        auto clpkg = "com.Microsoft.VisualStudio.VC.cl";
        auto cl = swctx.getPredefinedTargets().find(clpkg);

        auto clangpppkg = "org.LLVM.clangpp";
        auto clangpp = swctx.getPredefinedTargets().find(clpkg);

        auto clangclpkg = "org.LLVM.clangcl";
        auto clangcl = swctx.getPredefinedTargets().find(clangclpkg);

        auto gpppkg = "org.gnu.gpp";
        auto gpp = swctx.getPredefinedTargets().find(gpppkg);

        int counter{};
        if (0)
        {
        }
        // msvc
        if (cl != swctx.getPredefinedTargets().end(clpkg) && !cl->second.empty())
        {
            counter += check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("com.Microsoft.VisualStudio.VC.cl"));
            counter += check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("com.Microsoft.VisualStudio.VC.cl"));
            counter += check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("com.Microsoft.VisualStudio.VC.ml"));
            counter += check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("com.Microsoft.VisualStudio.VC.lib"));
            counter += check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("com.Microsoft.VisualStudio.VC.link"));

            if (counter) {
                add_stdlib();
                return;
            }
        }
        // clangcl
        if (clangcl != swctx.getPredefinedTargets().end(clangclpkg) && !clangcl->second.empty())
        {
            counter += check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("org.LLVM.clangcl"));
            counter += check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("org.LLVM.clangcl"));
            counter += check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("org.LLVM.clangcl"));
            // ?
            counter += check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("com.Microsoft.VisualStudio.VC.lib"));
            counter += check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("com.Microsoft.VisualStudio.VC.link"));

            if (counter) {
                add_stdlib();
                return;
            }
        }
        // clang
        if (clangpp != swctx.getPredefinedTargets().end(clangpppkg) && !clangpp->second.empty())
        {
            counter += check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("org.LLVM.clang"));
            counter += check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("org.LLVM.clangpp"));
            counter += check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("org.LLVM.clang"));
            // ?
            counter += check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("com.Microsoft.VisualStudio.VC.lib"));
            counter += check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("com.Microsoft.VisualStudio.VC.link"));

            if (counter) {
                add_stdlib();
                return;
            }
        }
        // gcc (mingw or other)
        if (gpp != swctx.getPredefinedTargets().end(gpppkg) && !gpp->second.empty())
        {
            counter += check_and_assign_dependency(ts["native"]["program"]["c"], to_upkg("org.gnu.gcc"));
            counter += check_and_assign_dependency(ts["native"]["program"]["cpp"], to_upkg("org.gnu.gpp"));
            counter += check_and_assign_dependency(ts["native"]["program"]["asm"], to_upkg("org.gnu.gcc"));
            // ?
            counter += check_and_assign_dependency(ts["native"]["program"]["lib"], to_upkg("org.gnu.binutils.ar"));
            counter += check_and_assign_dependency(ts["native"]["program"]["link"], to_upkg("org.gnu.gpp"));

            if (counter) {
                return;
            }
        }

        throw SW_RUNTIME_ERROR("No suitable compilers found.\nPlease, install one first.");
    }
    // add more defaults
    else
    {
        // set default libs?
        /*ts["native"]["stdlib"]["c"] = to_upkg("com.Microsoft.Windows.SDK.ucrt");
        ts["native"]["stdlib"]["cpp"] = to_upkg("com.Microsoft.VisualStudio.VC.libcpp");
        ts["native"]["stdlib"]["kernel"] = to_upkg("com.Microsoft.Windows.SDK.um");*/

        auto if_add = [&swctx, &check_and_assign_dependency](auto &s, const UnresolvedPackage &name)
        {
            auto &pd = swctx.getPredefinedTargets();
            auto i = pd.find(name);
            if (i == pd.end() || i->second.empty())
                return false;
            check_and_assign_dependency(s, name.toString());
            return true;
        };

        auto try_clang = [&if_add, &ts]()
        {
            if_add(ts["native"]["program"]["c"], "org.LLVM.clang"s);
            if_add(ts["native"]["program"]["cpp"], "org.LLVM.clangpp"s);
            if_add(ts["native"]["program"]["c"], "com.Apple.clang"s);
            if_add(ts["native"]["program"]["cpp"], "com.Apple.clangpp"s);
            //if (getHostOs().is(OSType::Linux))
            //ts["native"]["stdlib"]["cpp"] = to_upkg("org.sw.demo.llvm_project.libcxx");
        };

        auto try_gcc = [&if_add, &ts]()
        {
            if_add(ts["native"]["program"]["c"], "org.gnu.gcc"s);
            if_add(ts["native"]["program"]["cpp"], "org.gnu.gpp"s);
        };

        if (bs.TargetOS.is(OSType::Mingw))
            try_gcc();

#if defined(__clang__)
        try_clang();
        try_gcc();
//#elif defined(__GNUC__) || defined(__CYGWIN__)
#else
        try_gcc();
        try_clang();
#endif

        // using c prog
        if (ts["native"]["program"]["c"].isValue())
            if_add(ts["native"]["program"]["asm"], ts["native"]["program"]["c"].getValue());

        // reconsider, also with driver?
        check_and_assign_dependency(ts["native"]["program"]["lib"], "org.gnu.binutils.ar"s);

        // use driver
        // use cpp driver for the moment to not burden ourselves in adding stdlib
        if (ts["native"]["program"]["cpp"].isValue())
            if_add(ts["native"]["program"]["link"], ts["native"]["program"]["cpp"].getValue());
    }

#ifdef __APPLE__
    check_and_assign_dependency(ts["native"]["program"]["m"], to_upkg("com.Apple.clang"));
    check_and_assign_dependency(ts["native"]["program"]["mm"], to_upkg("com.Apple.clangpp"));
#endif
}

}
